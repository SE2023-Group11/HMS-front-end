const notifications = [
    {
        id: 1,
        title: '新消息1',
        description: '这是一条新的通知消息。',
        read: false
    },
    {
        id: 2,
        title: '新消息2',
        description: '这是另一个新的通知消息。',
        read: true
    }
]
export default notifications